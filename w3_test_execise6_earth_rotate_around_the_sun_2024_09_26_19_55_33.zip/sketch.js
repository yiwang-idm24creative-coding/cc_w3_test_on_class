//An orbit
//Make the earth rotate around the sun

let angle = 0;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  //set background to blue
  background("#0E55A1");

  //sun
  fill("#E2BA15");
  noStroke();
  ellipse(200, 200, 50, 50);

  //earth moving around the sun
  push();
  translate(200,200);
  rotate(angle); 
  fill("#177E79");
  noStroke();
  ellipse(100, 100, 30, 30);
  pop();
  
   angle += 1; // Adjust the speed of rotation (1 degree per frame)
}
