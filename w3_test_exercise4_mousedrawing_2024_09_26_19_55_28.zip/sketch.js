
//simple drawing sketch

function setup() {
  createCanvas(400, 400);
  background(220);
  
  
  let pMouseX = mouseX; //put mouse X position into a variable 
  let pMouseY = mouseY; //put mouse Y position into a variable
}

function draw() {
    

  line(mouseX, mouseY, pmouseX, pmouseY);  //draw a line from current mouse position to previous mouse position
  
  pMouseX = mouseX;  //put mouse X position into a variable 
  pMouseY = mouseY;  //put mouse Y position into a variable
  
  
}

