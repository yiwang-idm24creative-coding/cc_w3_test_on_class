let x1,x2;
let y1,y2;
    
function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER);
  x1 = width/4;
  x2 = 3*width/4;
  y1 =height/4;
  y2= 3*height/4;
}

function mousePressed(){
  background(220);
}

function draw() {
  // 1.Draw a rectangle in the middle of the screen
  stroke(255);
  fill(0,200,80);
  rect(width/2,height/2,100,100);
  
  // 2.Re-draw the rectangle using line
  stroke(100,200,90);
  translate(50,20);
  line(x1,y1,x2,y1);
  line(x1,y1,x1,y2);
  line(x1,y2,x2,y2);
  line(x2,y1,x2,y2);
 
}