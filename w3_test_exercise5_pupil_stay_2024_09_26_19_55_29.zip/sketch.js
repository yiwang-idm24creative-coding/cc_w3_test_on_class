//following eye

let eyeL;
let eyeR;

function setup() {
  createCanvas(400, 400);
  ellipseMode(CENTER);
  noStroke();
  //variable for pupil position
  pupilX = width / 2;
}

function draw() {
  background("#B2B666");
  
  // //move pupil
  // pupilX = mouseX;

  //face
  fill("#AA7769");
  ellipse(width / 2, 200, 250, 250); //ellipse(x,y,w,h);

  // eyeball

  fill(255); //white
  ellipse(width / 2, height / 3, 50, 50);

  //pupil
  fill(0); //black
  ellipse(pupilX, height / 3, 20, 20);
}
