  function setup() {
  createCanvas(windowWidth,windowHeight);
}

// function mousePressed(){

//3.Move a circle from the middle of the screen to the right side of the screen  
function draw(){
  background(220);
  noStroke();
  let x = frameCount * 1;
  let y = frameCount * 1 ;
  
  push();
  fill(250,0,30);
  translate(x,0);
  ellipse(width/2,height/2,200);
  pop();
  
  //a.Add 3 more, 1 moving left, 1 moving up, 1 moving down.
  //moving left:=+c.move 10 times faster than the other circles.
  push();
  fill(0,200,80);
  translate(-x*10,0);
  ellipse(width/2,height/2,200);
  pop();
  
  //moving up
  push();
  fill(0);
  translate(0,-y);
  ellipse(width/2,height/2,200);
  pop();
  
  //moving down
  push();
  fill(0,200,200);
  translate(0,y);
  ellipse(width/2,height/2,200);
  pop();
  
  // Add 4 more, each moving towards each of the 4 corners of the canvas.
  // push();
  // fill(200,40,30);
  // translate(50,y);
  // ellipse(width/2,height/2,50);
  // pop();
  
}
 

  